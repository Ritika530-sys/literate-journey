# cpu-scheduling-sim
CPU Scheduling Simulator

This application is built for my OS mini project. I'll continue developing this application which will include bug fixes and new features.
